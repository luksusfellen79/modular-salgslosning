import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

function generateCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  return Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
}

const DEMO_VENUES = [
  { name: 'Pingvinen', address: 'Vaskerelven 14, Bergen' },
  { name: 'Apollon Bar', address: 'Kong Oscars gate 18, Bergen' },
  { name: 'Altona Vinbar', address: 'Strandkaien 2, Bergen' },
  { name: 'Naboen', address: 'Nygårdsgaten 2, Bergen' },
  { name: 'Wesselstuen', address: 'Ole Bulls plass 6, Bergen' },
]

export default function HostSetup() {
  const [name, setName] = useState('')
  const [maxVeto, setMaxVeto] = useState(1)
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  async function handleStart(e) {
    e.preventDefault()
    setLoading(true)

    const { data: { user } } = await supabase.auth.getUser()

    // 1. Create a route
    const { data: route } = await supabase
      .from('routes')
      .insert({ owner_id: user.id, name: name || 'Kvelden vår', is_public: false })
      .select()
      .single()

    // 2. Upsert venues and create route stops
    for (let i = 0; i < DEMO_VENUES.length; i++) {
      const v = DEMO_VENUES[i]
      let { data: venue } = await supabase
        .from('venues')
        .select('id')
        .eq('name', v.name)
        .single()

      if (!venue) {
        const { data: newVenue } = await supabase
          .from('venues')
          .insert({ name: v.name, address: v.address, lat: 0, lng: 0 })
          .select()
          .single()
        venue = newVenue
      }

      await supabase.from('route_stops').insert({
        route_id: route.id,
        venue_id: venue.id,
        stop_order: i + 1,
        host_note: '',
      })
    }

    // 3. Create session
    const { data: session } = await supabase
      .from('sessions')
      .insert({
        route_id: route.id,
        host_id: user.id,
        join_code: generateCode(),
        status: 'lobby',
        current_stop_index: 0,
      })
      .select()
      .single()

    // 4. Add host as participant
    await supabase.from('session_participants').insert({
      session_id: session.id,
      profile_id: user.id,
      total_score: 0,
      veto_count: 0,
    })

    navigate(`/lobby/${session.id}`)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
      <div className="topbar">
        <button className="back-btn" onClick={() => navigate('/')}>← Tilbake</button>
        <h2>Ny kveld</h2>
      </div>

      <form onSubmit={handleStart} className="page">
        <div>
          <label style={{ fontSize: 13, color: '#888', marginBottom: 6, display: 'block' }}>Navn på kvelden</label>
          <input
            type="text"
            placeholder="F.eks. Fredagstur i Bergen"
            value={name}
            onChange={e => setName(e.target.value)}
          />
        </div>

        <div>
          <label style={{ fontSize: 13, color: '#888', marginBottom: 8, display: 'block' }}>Rute</label>
          <div className="card" style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <div style={{
              width: 32, height: 32, borderRadius: '50%',
              background: '#E1F5EE', color: '#0F6E56',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 13, fontWeight: 600,
            }}>5</div>
            <div>
              <p style={{ fontWeight: 500 }}>Bergen sentrum klassiker</p>
              <p className="text-muted">Demo-rute · 5 stopp</p>
            </div>
            <span style={{ marginLeft: 'auto', color: '#1D9E75', fontSize: 18 }}>✓</span>
          </div>
          <p className="text-muted" style={{ marginTop: 8, fontSize: 12 }}>
            Egne ruter kommer snart 🚧
          </p>
        </div>

        <div>
          <label style={{ fontSize: 13, color: '#888', marginBottom: 8, display: 'block' }}>Maks veto per person</label>
          <div style={{ display: 'flex', gap: 8 }}>
            {[1, 2, 3].map(n => (
              <button
                key={n}
                type="button"
                className="btn btn-sm"
                style={{
                  background: maxVeto === n ? '#E1F5EE' : '#fff',
                  borderColor: maxVeto === n ? '#1D9E75' : '#ddd',
                  color: maxVeto === n ? '#085041' : '#1a1a1a',
                  fontWeight: maxVeto === n ? 600 : 400,
                }}
                onClick={() => setMaxVeto(n)}
              >
                {n}
              </button>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 'auto' }}>
          <button className="btn btn-primary" type="submit" disabled={loading}>
            {loading ? 'Oppretter kveld...' : 'Start kveld og generer kode'}
          </button>
        </div>
      </form>
    </div>
  )
}
