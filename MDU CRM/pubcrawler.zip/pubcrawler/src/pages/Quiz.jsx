import { useEffect, useState, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

const DEMO_QUESTIONS = [
  {
    question: 'Pingvinen er kjent som en av Bergens mest tradisjonsrike barer. Hvilket tiår åpnet den?',
    options: ['1940-tallet', '1960-tallet', '1980-tallet', '2000-tallet'],
    correct_index: 1,
    points: 20,
  },
  {
    question: 'Hva er symbolet på Pingvinens logo?',
    options: ['En bjørn', 'En fisk', 'En pingvin', 'Et skip'],
    correct_index: 2,
    points: 10,
  },
  {
    question: 'Hvilket år ble Bergen grunnlagt?',
    options: ['1070', '1170', '1270', '1370'],
    correct_index: 0,
    points: 20,
  },
  {
    question: 'Hva heter det berømte UNESCO-verdensarvstedet i Bergen?',
    options: ['Fløyen', 'Bryggen', 'Bergenhus', 'Troldhaugen'],
    correct_index: 1,
    points: 10,
  },
]

const TIMER_SECONDS = 15

export default function Quiz() {
  const { sessionId } = useParams()
  const navigate = useNavigate()
  const [currentQ, setCurrentQ] = useState(0)
  const [selected, setSelected] = useState(null)
  const [answered, setAnswered] = useState(false)
  const [timeLeft, setTimeLeft] = useState(TIMER_SECONDS)
  const [score, setScore] = useState(0)
  const [correctCount, setCorrectCount] = useState(0)
  const [done, setDone] = useState(false)
  const [saving, setSaving] = useState(false)
  const timerRef = useRef(null)

  const q = DEMO_QUESTIONS[currentQ]

  useEffect(() => {
    if (answered) return
    setTimeLeft(TIMER_SECONDS)
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current)
          handleAnswer(null)
          return 0
        }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(timerRef.current)
  }, [currentQ, answered])

  function handleAnswer(idx) {
    if (answered) return
    clearInterval(timerRef.current)
    setSelected(idx)
    setAnswered(true)

    if (idx === q.correct_index) {
      const bonus = Math.round((timeLeft / TIMER_SECONDS) * q.points)
      setScore(prev => prev + q.points + bonus)
      setCorrectCount(prev => prev + 1)
    }

    setTimeout(() => {
      if (currentQ < DEMO_QUESTIONS.length - 1) {
        setCurrentQ(prev => prev + 1)
        setSelected(null)
        setAnswered(false)
      } else {
        setDone(true)
      }
    }, 1400)
  }

  async function saveAndReturn() {
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()

    await supabase
      .from('session_participants')
      .update({ total_score: supabase.rpc('increment', { x: score }) })
      .eq('session_id', sessionId)
      .eq('profile_id', user.id)

    // Simpler direct update: fetch current score and add
    const { data: p } = await supabase
      .from('session_participants')
      .select('total_score')
      .eq('session_id', sessionId)
      .eq('profile_id', user.id)
      .single()

    await supabase
      .from('session_participants')
      .update({ total_score: (p?.total_score || 0) + score })
      .eq('session_id', sessionId)
      .eq('profile_id', user.id)

    navigate(`/session/${sessionId}`)
  }

  if (done) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
        <div className="topbar">
          <h2>Quiz ferdig!</h2>
        </div>
        <div className="page" style={{ justifyContent: 'center', alignItems: 'center', flex: 1, gap: 20 }}>
          <div className="card" style={{ textAlign: 'center', background: '#E1F5EE', borderColor: '#1D9E75', width: '100%' }}>
            <p style={{ fontSize: 13, color: '#0F6E56', marginBottom: 4 }}>Du fikk</p>
            <p style={{ fontSize: 42, fontWeight: 700, color: '#085041' }}>{score} poeng</p>
            <p style={{ fontSize: 13, color: '#0F6E56' }}>{correctCount} av {DEMO_QUESTIONS.length} riktige</p>
          </div>

          <button className="btn btn-primary" onClick={saveAndReturn} disabled={saving}>
            {saving ? 'Lagrer...' : 'Lagre og tilbake'}
          </button>
        </div>
      </div>
    )
  }

  const progress = ((currentQ) / DEMO_QUESTIONS.length) * 100

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
      <div className="topbar">
        <h2>Spørsmål {currentQ + 1}/{DEMO_QUESTIONS.length}</h2>
        <span className="pill pill-green" style={{ fontSize: 11 }}>{score}p</span>
      </div>

      <div className="page">
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${progress}%` }} />
        </div>

        <div style={{
          fontSize: 32,
          fontWeight: 700,
          textAlign: 'center',
          color: timeLeft <= 5 ? '#E24B4A' : '#1D9E75',
          padding: '4px 0',
          transition: 'color 0.3s',
        }}>
          {timeLeft}
        </div>

        <div className="card-white">
          <p style={{ fontSize: 16, fontWeight: 500, lineHeight: 1.5 }}>{q.question}</p>
          <p className="text-muted" style={{ marginTop: 6, fontSize: 11 }}>
            Opptil {q.points} poeng · raskere = mer poeng
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {q.options.map((opt, i) => {
            let style = {}
            if (answered) {
              if (i === q.correct_index) {
                style = { background: '#E1F5EE', borderColor: '#1D9E75', color: '#085041' }
              } else if (i === selected && i !== q.correct_index) {
                style = { background: '#FCEBEB', borderColor: '#E24B4A', color: '#791F1F' }
              }
            }
            return (
              <button
                key={i}
                className="btn btn-secondary"
                style={{ textAlign: 'left', ...style }}
                onClick={() => handleAnswer(i)}
                disabled={answered}
              >
                {opt}
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
