import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

export default function Join() {
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  async function handleJoin(e) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const { data: session, error: err } = await supabase
      .from('sessions')
      .select('id, status')
      .eq('join_code', code.toUpperCase().trim())
      .single()

    if (err || !session) {
      setError('Fant ingen aktiv kveld med den koden. Sjekk at du skrev riktig.')
      setLoading(false)
      return
    }

    if (session.status === 'ended') {
      setError('Denne kvelden er allerede avsluttet.')
      setLoading(false)
      return
    }

    const { data: { user } } = await supabase.auth.getUser()

    await supabase.from('session_participants').upsert({
      session_id: session.id,
      profile_id: user.id,
      total_score: 0,
      veto_count: 0,
    }, { onConflict: 'session_id,profile_id' })

    navigate(`/lobby/${session.id}`)
  }

  return (
    <div className="page" style={{ flex: 1 }}>
      <div className="topbar" style={{ margin: '-16px -16px 0', padding: '14px 16px' }}>
        <button className="back-btn" onClick={() => navigate('/')}>← Tilbake</button>
        <h2>Bli med</h2>
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 16, marginTop: 32 }}>
        <p className="text-muted text-center">Skriv inn koden du fikk fra hosten</p>

        <form onSubmit={handleJoin} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <input
            type="text"
            placeholder="F.eks. BEER42"
            value={code}
            onChange={e => setCode(e.target.value.toUpperCase())}
            maxLength={8}
            style={{ textAlign: 'center', fontSize: 28, letterSpacing: 6, fontWeight: 600 }}
            autoFocus
          />
          {error && <p style={{ color: '#e24b4a', fontSize: 13, textAlign: 'center' }}>{error}</p>}
          <button className="btn btn-primary" type="submit" disabled={loading || !code}>
            {loading ? 'Sjekker...' : 'Bli med'}
          </button>
        </form>
      </div>
    </div>
  )
}
