import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

export default function Home() {
  const navigate = useNavigate()

  return (
    <div className="page" style={{ justifyContent: 'center', flex: 1, gap: 20 }}>
      <div style={{ textAlign: 'center', marginBottom: 8 }}>
        <div style={{ fontSize: 52, marginBottom: 12 }}>🍺</div>
        <h1>Pub Crawler</h1>
        <p className="text-muted" style={{ marginTop: 6 }}>
          Start en ny kveld eller bli med i en gruppe
        </p>
      </div>

      <div className="gap-12">
        <button className="btn btn-primary" onClick={() => navigate('/host')}>
          Start kveld som host
        </button>
        <button className="btn btn-secondary" onClick={() => navigate('/join')}>
          Bli med med kode
        </button>
      </div>

      <div className="divider" />

      <button
        className="btn btn-secondary"
        style={{ color: '#888', borderColor: '#eee' }}
        onClick={async () => {
          await supabase.auth.signOut()
        }}
      >
        Logg ut
      </button>
    </div>
  )
}
