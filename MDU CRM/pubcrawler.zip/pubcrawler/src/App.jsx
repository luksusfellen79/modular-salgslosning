import { Routes, Route, Navigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { supabase } from './lib/supabase'

import Home from './pages/Home'
import Join from './pages/Join'
import HostSetup from './pages/HostSetup'
import Lobby from './pages/Lobby'
import Session from './pages/Session'
import Quiz from './pages/Quiz'
import Login from './pages/Login'

export default function App() {
  const [session, setSession] = useState(undefined)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => setSession(session))
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => setSession(s))
    return () => subscription.unsubscribe()
  }, [])

  if (session === undefined) {
    return (
      <div className="app-shell" style={{ justifyContent: 'center', alignItems: 'center' }}>
        <p className="text-muted">Laster...</p>
      </div>
    )
  }

  return (
    <div className="app-shell">
      <Routes>
        <Route path="/login" element={!session ? <Login /> : <Navigate to="/" />} />
        <Route path="/" element={session ? <Home /> : <Navigate to="/login" />} />
        <Route path="/join" element={session ? <Join /> : <Navigate to="/login" />} />
        <Route path="/host" element={session ? <HostSetup /> : <Navigate to="/login" />} />
        <Route path="/lobby/:sessionId" element={session ? <Lobby /> : <Navigate to="/login" />} />
        <Route path="/session/:sessionId" element={session ? <Session /> : <Navigate to="/login" />} />
        <Route path="/session/:sessionId/quiz" element={session ? <Quiz /> : <Navigate to="/login" />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </div>
  )
}
