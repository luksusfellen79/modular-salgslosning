-- Run this in Supabase SQL editor

-- Profiles (linked to auth.users)
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  avatar_url text,
  created_at timestamptz default now()
);

-- Auto-create profile on signup
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- Venues
create table if not exists venues (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text,
  lat float,
  lng float,
  mapbox_place_id text,
  created_at timestamptz default now()
);

-- Routes
create table if not exists routes (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references profiles(id) on delete set null,
  name text not null,
  description text,
  is_public boolean default false,
  created_at timestamptz default now()
);

-- Route stops
create table if not exists route_stops (
  id uuid primary key default gen_random_uuid(),
  route_id uuid references routes(id) on delete cascade,
  venue_id uuid references venues(id) on delete cascade,
  stop_order int not null,
  host_note text
);

-- Sessions
create table if not exists sessions (
  id uuid primary key default gen_random_uuid(),
  route_id uuid references routes(id) on delete set null,
  host_id uuid references profiles(id) on delete set null,
  join_code text unique not null,
  status text default 'lobby' check (status in ('lobby', 'active', 'ended')),
  current_stop_index int default 0,
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz default now()
);

-- Session participants
create table if not exists session_participants (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references sessions(id) on delete cascade,
  profile_id uuid references profiles(id) on delete cascade,
  total_score int default 0,
  veto_count int default 0,
  joined_at timestamptz default now(),
  unique(session_id, profile_id)
);

-- Quizzes
create table if not exists quizzes (
  id uuid primary key default gen_random_uuid(),
  venue_id uuid references venues(id) on delete cascade,
  created_by uuid references profiles(id) on delete set null,
  title text,
  created_at timestamptz default now()
);

-- Quiz questions
create table if not exists quiz_questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid references quizzes(id) on delete cascade,
  question text not null,
  options text[] not null,
  correct_index int not null,
  points int default 10
);

-- Quiz answers
create table if not exists quiz_answers (
  id uuid primary key default gen_random_uuid(),
  question_id uuid references quiz_questions(id) on delete cascade,
  participant_id uuid references session_participants(id) on delete cascade,
  chosen_index int,
  is_correct boolean,
  points_earned int default 0,
  answered_at timestamptz default now()
);

-- Venue votes
create table if not exists venue_votes (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references sessions(id) on delete cascade,
  profile_id uuid references profiles(id) on delete cascade,
  venue_id uuid references venues(id) on delete cascade,
  vote_type text check (vote_type in ('veto', 'suggest', 'approve')),
  voted_at timestamptz default now()
);

-- Enable RLS on all tables
alter table profiles enable row level security;
alter table venues enable row level security;
alter table routes enable row level security;
alter table route_stops enable row level security;
alter table sessions enable row level security;
alter table session_participants enable row level security;
alter table quizzes enable row level security;
alter table quiz_questions enable row level security;
alter table quiz_answers enable row level security;
alter table venue_votes enable row level security;

-- RLS policies (permissive for now, tighten later)
create policy "Public read profiles" on profiles for select using (true);
create policy "Own profile write" on profiles for all using (auth.uid() = id);

create policy "Public read venues" on venues for select using (true);
create policy "Auth insert venues" on venues for insert with check (auth.uid() is not null);

create policy "Public read routes" on routes for select using (is_public or owner_id = auth.uid());
create policy "Auth write routes" on routes for all using (owner_id = auth.uid());

create policy "Public read stops" on route_stops for select using (true);
create policy "Auth write stops" on route_stops for all using (
  exists (select 1 from routes where id = route_stops.route_id and owner_id = auth.uid())
);

create policy "Public read sessions" on sessions for select using (true);
create policy "Auth write sessions" on sessions for all using (host_id = auth.uid());

create policy "Public read participants" on session_participants for select using (true);
create policy "Auth write participants" on session_participants for all using (profile_id = auth.uid());

create policy "Public read quizzes" on quizzes for select using (true);
create policy "Auth write quizzes" on quizzes for all using (created_by = auth.uid());

create policy "Public read questions" on quiz_questions for select using (true);
create policy "Auth write questions" on quiz_questions for insert with check (
  exists (select 1 from quizzes where id = quiz_questions.quiz_id and created_by = auth.uid())
);

create policy "Public read answers" on quiz_answers for select using (true);
create policy "Auth write answers" on quiz_answers for all using (
  exists (select 1 from session_participants where id = quiz_answers.participant_id and profile_id = auth.uid())
);

create policy "Public read votes" on venue_votes for select using (true);
create policy "Auth write votes" on venue_votes for all using (profile_id = auth.uid());

-- Enable realtime on key tables
alter publication supabase_realtime add table sessions;
alter publication supabase_realtime add table session_participants;
alter publication supabase_realtime add table quiz_answers;
