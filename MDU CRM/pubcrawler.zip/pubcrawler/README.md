# Pub Crawler 🍺

En sosial pub crawler-app for grupper. Quiz, scoreboard og rute – alt i én app.

## Kom i gang

### 1. Supabase

1. Opprett et prosjekt på [supabase.com](https://supabase.com)
2. Gå til **SQL Editor** og kjør innholdet i `supabase-schema.sql`
3. Gå til **Project Settings → API** og kopier:
   - `Project URL`
   - `anon public` key

### 2. Miljøvariabler

Lag en `.env.local` fil i prosjektmappen:

```
VITE_SUPABASE_URL=https://ditt-prosjekt.supabase.co
VITE_SUPABASE_ANON_KEY=din-anon-nøkkel
```

### 3. Kjør lokalt

```bash
npm install
npm run dev
```

### 4. Deploy til Vercel

1. Push til GitHub
2. Importer repo på [vercel.com](https://vercel.com)
3. Legg til miljøvariablene under **Settings → Environment Variables**
4. Deploy!

## Funksjoner

- Magic link innlogging (ingen passord)
- Host starter kveld og deler kode
- Deltakere blir med via kode
- Realtime deltakerliste i lobby
- Quiz per stopp med nedtelling
- Poeng lagres og vises på scoreboard
- Rute-oversikt med nåværende stopp

## Kommende

- [ ] AI-genererte spørsmål per bar (Supabase Edge Function)
- [ ] Kart-visning med Mapbox
- [ ] Veto-system
- [ ] Egendefinerte ruter
- [ ] Slutt-seremoni med totalvinner
