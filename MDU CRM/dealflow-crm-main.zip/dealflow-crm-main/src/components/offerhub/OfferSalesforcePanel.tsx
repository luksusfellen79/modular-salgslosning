import React, { useState } from 'react';
import { Cloud, RefreshCw, ChevronRight, User, Calendar, DollarSign, Hash } from 'lucide-react';
import { OFFER_SF_OPPORTUNITIES, SfOpportunity } from '@/data/offerHubData';
import { cn } from '@/lib/utils';

interface OfferSalesforcePanelProps {
  onSelectOpportunity?: (opp: SfOpportunity) => void;
  selectedId?: string;
}

const stageColors: Record<string, string> = {
  'Needs Analysis': 'bg-warning/10 text-warning',
  'Value Proposition': 'bg-primary/10 text-primary',
  'Proposal/Price Quote': 'bg-stage-proposal/10 text-stage-proposal',
  'Negotiation/Review': 'bg-stage-qualification/10 text-stage-qualification',
  'Closed Won': 'bg-success/10 text-success',
};

export const OfferSalesforcePanel: React.FC<OfferSalesforcePanelProps> = ({ onSelectOpportunity, selectedId }) => {
  const [syncing, setSyncing] = useState(false);

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 1500);
  };

  return (
    <div className="rounded-xl border bg-card p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-primary">
            <Cloud className="w-4 h-4 text-primary-foreground" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-foreground">Salesforce</h3>
            <p className="text-[10px] text-muted-foreground">Mock connector</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold bg-success/10 text-success">
            <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" /> Tilkoblet
          </span>
          <button onClick={handleSync} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
            <RefreshCw className={cn('w-3.5 h-3.5 text-muted-foreground', syncing && 'animate-spin')} />
          </button>
        </div>
      </div>

      <p className="text-[10px] text-muted-foreground mb-3">Siste synk: i dag 10:42</p>
      <p className="text-xs font-semibold text-foreground mb-2 uppercase tracking-wide">Aktive Muligheter</p>

      <div className="space-y-2">
        {OFFER_SF_OPPORTUNITIES.map((opp) => (
          <button
            key={opp.id}
            onClick={() => onSelectOpportunity?.(opp)}
            className={cn(
              'w-full text-left p-3 rounded-xl border transition-all duration-200',
              selectedId === opp.id ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/30 hover:bg-muted/50'
            )}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-foreground truncate">{opp.accountName}</p>
                <p className="text-[10px] text-muted-foreground truncate">{opp.name}</p>
              </div>
              <ChevronRight className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />
            </div>
            <div className="mt-2 flex flex-wrap gap-1">
              <span className={cn('text-[10px] font-medium px-1.5 py-0.5 rounded-full', stageColors[opp.stage] || 'bg-muted text-muted-foreground')}>
                {opp.stage}
              </span>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              <div className="flex items-center gap-1"><User className="w-2.5 h-2.5 text-muted-foreground" /><span className="text-[10px] text-muted-foreground truncate">{opp.contactName}</span></div>
              <div className="flex items-center gap-1"><Hash className="w-2.5 h-2.5 text-muted-foreground" /><span className="text-[10px] text-muted-foreground">{opp.units} enheter</span></div>
              <div className="flex items-center gap-1"><Calendar className="w-2.5 h-2.5 text-muted-foreground" /><span className="text-[10px] text-muted-foreground">{opp.closeDate}</span></div>
              <div className="flex items-center gap-1"><DollarSign className="w-2.5 h-2.5 text-muted-foreground" /><span className="text-[10px] text-muted-foreground">{(opp.amount / 1000).toFixed(0)}k kr/år</span></div>
            </div>
            {selectedId === opp.id && <p className="text-[10px] font-semibold text-primary mt-2">✓ Valgt for tilbud</p>}
          </button>
        ))}
      </div>
    </div>
  );
};
